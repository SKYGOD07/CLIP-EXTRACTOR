import { z } from 'zod';
import { insertVideoSchema, insertClipSchema, videos, clips } from './schema';

export const api = {
  videos: {
    list: {
      method: 'GET' as const,
      path: '/api/videos',
      responses: {
        200: z.array(z.custom<typeof videos.$inferSelect>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/videos/:id',
      responses: {
        200: z.custom<typeof videos.$inferSelect & { clips: typeof clips.$inferSelect[] }>(),
        404: z.object({ message: z.string() }),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/videos',
      input: insertVideoSchema,
      responses: {
        201: z.custom<typeof videos.$inferSelect>(),
        400: z.object({ message: z.string() }),
      },
    },
    process: {
      method: 'POST' as const,
      path: '/api/videos/:id/process',
      responses: {
        200: z.object({ message: z.string() }),
        404: z.object({ message: z.string() }),
      },
    },
    uploadUrl: {
      method: 'POST' as const,
      path: '/api/upload-url',
      input: z.object({
        filename: z.string(),
        contentType: z.string(),
        size: z.number(),
      }),
      responses: {
        200: z.object({
          uploadUrl: z.string(),
          publicUrl: z.string(),
        }),
      },
    }
  },
};

// Helper for frontend to build URLs with params
export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      url = url.replace(`:${key}`, String(value));
    });
  }
  return url;
}
