import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const videos = pgTable("videos", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  originalUrl: text("original_url").notNull(),
  status: text("status").notNull().default("uploaded"), // uploaded, processing, completed, failed
  progress: integer("progress").default(0),
  error: text("error"),
  metadata: jsonb("metadata"), // Duration, dimensions, etc.
  createdAt: timestamp("created_at").defaultNow(),
});

export const clips = pgTable("clips", {
  id: serial("id").primaryKey(),
  videoId: integer("video_id").notNull(),
  url: text("url").notNull(),
  startTime: text("start_time").notNull(), // formatted timestamp or seconds
  endTime: text("end_time").notNull(),
  summary: text("summary").notNull(),
  viralityScore: integer("virality_score"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertVideoSchema = createInsertSchema(videos).omit({ 
  id: true, 
  createdAt: true, 
  status: true,
  progress: true,
  error: true 
});

export const insertClipSchema = createInsertSchema(clips).omit({ 
  id: true, 
  createdAt: true 
});

export type Video = typeof videos.$inferSelect;
export type InsertVideo = z.infer<typeof insertVideoSchema>;
export type Clip = typeof clips.$inferSelect;
export type InsertClip = z.infer<typeof insertClipSchema>;

export type VideoStatus = "uploaded" | "processing" | "completed" | "failed";
