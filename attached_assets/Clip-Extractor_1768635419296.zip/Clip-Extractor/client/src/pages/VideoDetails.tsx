import { useVideo } from "@/hooks/use-videos";
import { Link, useRoute } from "wouter";
import { ArrowLeft, Download, PlayCircle, Share2, Sparkles, Clock } from "lucide-react";
import ReactPlayer from "react-player";
import { motion } from "framer-motion";
import { StatusBadge } from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { format } from "date-fns";

export default function VideoDetails() {
  const [_, params] = useRoute("/videos/:id");
  const id = parseInt(params?.id || "0");
  const { data: video, isLoading, error } = useVideo(id);

  if (isLoading) return <div className="text-center py-20 animate-pulse text-muted-foreground">Loading analysis...</div>;
  if (error || !video) return <div className="text-center py-20 text-destructive">Video not found</div>;

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      {/* Header */}
      <div className="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center">
        <div className="space-y-2">
          <Link href="/" className="inline-flex items-center text-sm text-muted-foreground hover:text-primary transition-colors mb-2">
            <ArrowLeft className="w-4 h-4 mr-1" /> Back to Dashboard
          </Link>
          <h1 className="text-3xl sm:text-4xl font-display font-bold text-gradient">{video.title}</h1>
          <div className="flex items-center gap-3 text-sm text-muted-foreground">
             <StatusBadge status={video.status as any} />
             <span>•</span>
             <span>Uploaded {format(new Date(video.createdAt || Date.now()), "MMMM d, yyyy")}</span>
          </div>
        </div>
        <div className="flex gap-2">
          {video.status === 'completed' && (
            <Button variant="outline" className="gap-2">
              <Share2 className="w-4 h-4" /> Share
            </Button>
          )}
        </div>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: Original Video */}
        <div className="lg:col-span-2 space-y-6">
          <Card className="border-border/50 bg-card/40 backdrop-blur-sm overflow-hidden">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <PlayCircle className="w-5 h-5 text-primary" />
                Original Source
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0 aspect-video bg-black relative">
              <ReactPlayer 
                url={video.originalUrl} 
                width="100%" 
                height="100%" 
                controls
                light={false} // Use false to preload
                config={{ file: { attributes: { controlsList: 'nodownload' } } }}
              />
            </CardContent>
          </Card>

          {/* AI Metadata / Stats (Future Feature) */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
             {['Duration', 'Resolution', 'Format', 'Size'].map((label) => (
                <div key={label} className="bg-secondary/30 p-4 rounded-xl border border-border/50">
                   <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">{label}</p>
                   <p className="font-mono text-sm">--</p>
                </div>
             ))}
          </div>
        </div>

        {/* Right Column: Clips List */}
        <div className="lg:col-span-1">
          <div className="flex items-center gap-2 mb-4">
             <Sparkles className="w-5 h-5 text-accent" />
             <h2 className="text-xl font-bold font-display">Extracted Clips</h2>
             <span className="ml-auto bg-primary/20 text-primary text-xs px-2 py-1 rounded-full">
                {video.clips?.length || 0}
             </span>
          </div>

          <div className="space-y-4 max-h-[800px] overflow-y-auto pr-2 custom-scrollbar">
            {video.clips && video.clips.length > 0 ? (
              video.clips.map((clip, idx) => (
                <motion.div
                  key={clip.id}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.1 }}
                >
                  <Card className="border-border/50 bg-card hover:border-primary/50 transition-colors group overflow-hidden">
                    <div className="aspect-[16/9] bg-black relative">
                       <ReactPlayer 
                          url={clip.url} 
                          width="100%" 
                          height="100%" 
                          controls 
                          light={true} // Simple thumbnail mode
                          playIcon={<div className="w-12 h-12 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center group-hover:scale-110 transition-transform"><PlayCircle className="w-6 h-6 text-white" /></div>}
                       />
                       <div className="absolute bottom-2 right-2 bg-black/60 backdrop-blur text-white text-[10px] px-2 py-0.5 rounded font-mono flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {clip.startTime} - {clip.endTime}
                       </div>
                    </div>
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between gap-2 mb-2">
                         <p className="text-sm font-medium line-clamp-2 leading-snug">
                            {clip.summary}
                         </p>
                         {clip.viralityScore && (
                            <div className="flex flex-col items-center">
                               <div className="text-xs font-bold text-accent">{clip.viralityScore}</div>
                               <div className="text-[10px] text-muted-foreground uppercase">Score</div>
                            </div>
                         )}
                      </div>
                      
                      <div className="pt-3 mt-3 border-t border-border/30 flex justify-end">
                        <a 
                          href={clip.url} 
                          download={`clip-${clip.id}.mp4`}
                          target="_blank"
                          rel="noreferrer"
                        >
                           <Button size="sm" variant="secondary" className="h-8 text-xs gap-1.5 hover:bg-primary hover:text-white transition-colors">
                              <Download className="w-3.5 h-3.5" />
                              Download
                           </Button>
                        </a>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))
            ) : (
              <div className="text-center py-12 px-4 border border-dashed border-border/50 rounded-xl bg-secondary/5">
                <p className="text-muted-foreground text-sm">
                   {video.status === 'processing' 
                      ? "AI is currently analyzing your video to find the best moments..." 
                      : "No clips extracted yet."}
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
