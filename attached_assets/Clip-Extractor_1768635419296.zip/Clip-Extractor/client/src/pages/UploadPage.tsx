import { useState } from "react";
import { useLocation } from "wouter";
import { UploadZone } from "@/components/UploadZone";
import { useGetUploadUrl, useCreateVideo } from "@/hooks/use-videos";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function UploadPage() {
  const [_, setLocation] = useLocation();
  const { toast } = useToast();
  const getUploadUrlMutation = useGetUploadUrl();
  const createVideoMutation = useCreateVideo();

  const [file, setFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [progress, setProgress] = useState(0);

  const handleFileSelect = (selectedFile: File) => {
    setFile(selectedFile);
  };

  const handleUpload = async () => {
    if (!file) return;

    try {
      setIsUploading(true);
      setProgress(10); // Started

      // 1. Get Presigned URL
      const { uploadUrl, publicUrl } = await getUploadUrlMutation.mutateAsync({
        filename: file.name,
        contentType: file.type,
        size: file.size,
      });

      setProgress(30); // Got URL

      // 2. Upload to Object Storage
      // NOTE: Using xhr for progress tracking could be added here, sticking to fetch for simplicity in this generated code
      const uploadRes = await fetch(uploadUrl, {
        method: "PUT",
        body: file,
        headers: {
          "Content-Type": file.type,
        },
      });

      if (!uploadRes.ok) throw new Error("Upload to storage failed");

      setProgress(80); // File uploaded

      // 3. Create Record in DB
      await createVideoMutation.mutateAsync({
        title: file.name,
        originalUrl: publicUrl,
      });

      setProgress(100); // Done

      toast({
        title: "Success!",
        description: "Video uploaded successfully. Processing started.",
      });

      // Redirect to home
      setTimeout(() => setLocation("/"), 500);

    } catch (error) {
      console.error(error);
      toast({
        variant: "destructive",
        title: "Upload Failed",
        description: "Something went wrong while uploading your video.",
      });
      setIsUploading(false);
      setProgress(0);
    }
  };

  return (
    <div className="max-w-3xl mx-auto py-8 animate-in slide-in-from-bottom-4 duration-500">
      <div className="mb-8 flex items-center gap-4">
        <Button 
          variant="ghost" 
          onClick={() => setLocation("/")}
          className="hover:bg-secondary/50"
        >
          <ArrowLeft className="w-5 h-5 mr-2" />
          Cancel
        </Button>
        <h1 className="text-3xl font-display font-bold">New Project</h1>
      </div>

      <div className="space-y-8">
        <UploadZone 
          onFileSelect={handleFileSelect} 
          isUploading={isUploading}
          progress={progress}
        />

        {file && !isUploading && (
           <div className="flex justify-end gap-4">
             <Button 
               variant="outline" 
               onClick={() => setFile(null)}
               className="border-destructive/30 text-destructive hover:bg-destructive/10 hover:text-destructive"
             >
               Remove File
             </Button>
             <Button 
               size="lg"
               onClick={handleUpload}
               className="bg-primary text-primary-foreground hover:bg-primary/90 px-8"
             >
               Upload & Process
             </Button>
           </div>
        )}

        {isUploading && (
           <div className="flex items-center justify-center gap-2 text-muted-foreground animate-pulse">
             <Loader2 className="w-5 h-5 animate-spin" />
             <span>Uploading and initiating AI pipeline...</span>
           </div>
        )}
      </div>
    </div>
  );
}
