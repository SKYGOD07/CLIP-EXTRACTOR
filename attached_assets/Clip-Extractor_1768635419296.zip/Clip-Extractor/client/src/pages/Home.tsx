import { useVideos, useProcessVideo } from "@/hooks/use-videos";
import { Link } from "wouter";
import { Plus, Play, Sparkles, ChevronRight, ArrowRight } from "lucide-react";
import { motion } from "framer-motion";
import { format } from "date-fns";
import { StatusBadge } from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";

export default function Home() {
  const { data: videos, isLoading, error } = useVideos();
  const processVideo = useProcessVideo();

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[50vh] space-y-4">
        <div className="w-12 h-12 rounded-full border-4 border-primary/30 border-t-primary animate-spin" />
        <p className="text-muted-foreground animate-pulse">Loading your dashboard...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[40vh] text-center p-8 border border-destructive/20 bg-destructive/5 rounded-3xl">
        <h3 className="text-xl font-bold text-destructive mb-2">Failed to load videos</h3>
        <p className="text-muted-foreground mb-4">Something went wrong while fetching your data.</p>
        <Button variant="outline" onClick={() => window.location.reload()}>Retry</Button>
      </div>
    );
  }

  const hasVideos = videos && videos.length > 0;

  return (
    <div className="space-y-10">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6">
        <div>
          <h1 className="text-4xl font-display font-bold mb-2">Dashboard</h1>
          <p className="text-muted-foreground text-lg">Manage your videos and AI clips.</p>
        </div>
        <Link href="/upload">
          <Button size="lg" className="rounded-xl px-6 h-12 text-md shadow-lg shadow-primary/20 hover:shadow-primary/40 transition-all">
            <Plus className="mr-2 h-5 w-5" />
            New Project
          </Button>
        </Link>
      </div>

      {!hasVideos ? (
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center py-24 px-6 rounded-3xl border border-dashed border-border/60 bg-card/30"
        >
          <div className="w-20 h-20 bg-secondary rounded-full flex items-center justify-center mx-auto mb-6">
            <Sparkles className="w-10 h-10 text-primary/60" />
          </div>
          <h2 className="text-2xl font-bold mb-3">No videos yet</h2>
          <p className="text-muted-foreground max-w-md mx-auto mb-8">
            Upload your first video to start extracting viral clips automatically with our AI engine.
          </p>
          <Link href="/upload">
            <Button variant="secondary" size="lg">Start Creating</Button>
          </Link>
        </motion.div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {videos.map((video, idx) => (
            <motion.div
              key={video.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.05 }}
              className="group relative bg-card rounded-2xl border border-border/50 overflow-hidden hover:border-primary/50 transition-all duration-300 hover:shadow-xl hover:shadow-primary/5 flex flex-col"
            >
              {/* Thumbnail Area Placeholder */}
              <div className="aspect-video bg-secondary/50 relative overflow-hidden flex items-center justify-center group-hover:bg-secondary/70 transition-colors">
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent z-10 opacity-60" />
                
                <Play className="w-12 h-12 text-white/80 z-20 opacity-50 group-hover:scale-110 transition-transform duration-300" />
                
                <div className="absolute top-4 right-4 z-20">
                  <StatusBadge status={video.status as any} />
                </div>
                
                <div className="absolute bottom-4 left-4 z-20">
                  <p className="text-white font-mono text-xs opacity-80">
                    {format(new Date(video.createdAt || Date.now()), "MMM d, yyyy")}
                  </p>
                </div>
              </div>

              <div className="p-6 flex flex-col flex-1">
                <h3 className="font-display font-bold text-lg mb-2 line-clamp-1 group-hover:text-primary transition-colors">
                  {video.title}
                </h3>
                <p className="text-sm text-muted-foreground line-clamp-2 mb-6 flex-1">
                  Original file uploaded via dashboard.
                </p>

                <div className="flex items-center justify-between mt-auto pt-4 border-t border-border/40">
                  {video.status === 'uploaded' ? (
                    <Button 
                      onClick={() => processVideo.mutate(video.id)}
                      disabled={processVideo.isPending}
                      variant="default"
                      className="w-full bg-gradient-to-r from-primary to-accent border-0"
                    >
                      {processVideo.isPending ? "Starting..." : (
                        <>
                          <Sparkles className="w-4 h-4 mr-2" />
                          Generate Clips
                        </>
                      )}
                    </Button>
                  ) : video.status === 'completed' ? (
                    <Link href={`/videos/${video.id}`} className="w-full">
                      <Button variant="outline" className="w-full group/btn border-primary/20 hover:bg-primary/5 hover:text-primary hover:border-primary/50">
                        View Results
                        <ArrowRight className="w-4 h-4 ml-2 group-hover/btn:translate-x-1 transition-transform" />
                      </Button>
                    </Link>
                  ) : video.status === 'processing' ? (
                     <div className="w-full text-center">
                        <p className="text-xs text-amber-500 font-medium animate-pulse mb-2">AI Analysis in Progress...</p>
                        <div className="h-1.5 w-full bg-secondary rounded-full overflow-hidden">
                           <div className="h-full bg-amber-500 w-1/2 animate-[shimmer_2s_infinite]" />
                        </div>
                     </div>
                  ) : (
                    <Button variant="ghost" className="w-full text-destructive hover:text-destructive hover:bg-destructive/10" disabled>
                      Processing Failed
                    </Button>
                  )}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
