import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { z } from "zod";
import type { Video, InsertVideo, Clip } from "@shared/schema";

// Type definitions matching the schema and API contract
export type VideoWithClips = Video & { clips: Clip[] };

export function useVideos() {
  return useQuery({
    queryKey: [api.videos.list.path],
    queryFn: async () => {
      const res = await fetch(api.videos.list.path);
      if (!res.ok) throw new Error("Failed to fetch videos");
      return api.videos.list.responses[200].parse(await res.json());
    },
    // Poll every 5 seconds if we have processing videos to keep UI updated
    refetchInterval: (query) => {
      const videos = query.state.data;
      if (videos?.some(v => v.status === "processing")) {
        return 5000;
      }
      return false;
    }
  });
}

export function useVideo(id: number) {
  return useQuery({
    queryKey: [api.videos.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.videos.get.path, { id });
      const res = await fetch(url);
      if (!res.ok) {
        if (res.status === 404) return null;
        throw new Error("Failed to fetch video details");
      }
      return api.videos.get.responses[200].parse(await res.json());
    },
    refetchInterval: (query) => {
      const video = query.state.data;
      if (video?.status === "processing") {
        return 3000; // Poll faster for individual video page
      }
      return false;
    }
  });
}

export function useGetUploadUrl() {
  return useMutation({
    mutationFn: async (fileData: { filename: string; contentType: string; size: number }) => {
      const res = await fetch(api.videos.uploadUrl.path, {
        method: api.videos.uploadUrl.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(fileData),
      });
      if (!res.ok) throw new Error("Failed to get upload URL");
      return api.videos.uploadUrl.responses[200].parse(await res.json());
    },
  });
}

export function useCreateVideo() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: InsertVideo) => {
      const res = await fetch(api.videos.create.path, {
        method: api.videos.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to create video record");
      return api.videos.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.videos.list.path] });
    },
  });
}

export function useProcessVideo() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.videos.process.path, { id });
      const res = await fetch(url, {
        method: api.videos.process.method,
      });
      if (!res.ok) throw new Error("Failed to start processing");
      return api.videos.process.responses[200].parse(await res.json());
    },
    onSuccess: (_, id) => {
      queryClient.invalidateQueries({ queryKey: [api.videos.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.videos.get.path, id] });
    },
  });
}
