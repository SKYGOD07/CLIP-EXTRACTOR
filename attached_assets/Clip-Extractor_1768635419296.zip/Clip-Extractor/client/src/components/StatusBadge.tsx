import { cn } from "@/lib/utils";
import { CheckCircle2, CircleDashed, Clock, XCircle } from "lucide-react";
import type { VideoStatus } from "@shared/schema";

interface StatusBadgeProps {
  status: VideoStatus;
  className?: string;
}

export function StatusBadge({ status, className }: StatusBadgeProps) {
  const config = {
    uploaded: {
      icon: Clock,
      label: "Uploaded",
      styles: "bg-blue-500/10 text-blue-500 border-blue-500/20",
    },
    processing: {
      icon: CircleDashed,
      label: "Processing AI",
      styles: "bg-amber-500/10 text-amber-500 border-amber-500/20 animate-pulse",
    },
    completed: {
      icon: CheckCircle2,
      label: "Completed",
      styles: "bg-emerald-500/10 text-emerald-500 border-emerald-500/20",
    },
    failed: {
      icon: XCircle,
      label: "Failed",
      styles: "bg-red-500/10 text-red-500 border-red-500/20",
    },
  };

  const { icon: Icon, label, styles } = config[status] || config.uploaded;

  return (
    <div
      className={cn(
        "inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium border",
        styles,
        className
      )}
    >
      <Icon className={cn("w-3.5 h-3.5", status === "processing" && "animate-spin")} />
      <span>{label}</span>
    </div>
  );
}
