import { useCallback, useState } from "react";
import { useDropzone } from "react-dropzone";
import { UploadCloud, FileVideo, AlertCircle, CheckCircle } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";

interface UploadZoneProps {
  onFileSelect: (file: File) => void;
  isUploading?: boolean;
  progress?: number;
  error?: string | null;
}

export function UploadZone({ onFileSelect, isUploading, progress = 0, error }: UploadZoneProps) {
  const onDrop = useCallback((acceptedFiles: File[]) => {
    if (acceptedFiles?.length > 0) {
      onFileSelect(acceptedFiles[0]);
    }
  }, [onFileSelect]);

  const { getRootProps, getInputProps, isDragActive, acceptedFiles } = useDropzone({
    onDrop,
    accept: { 'video/*': [] },
    maxFiles: 1,
    disabled: isUploading,
  });

  const activeFile = acceptedFiles[0];

  return (
    <div className="w-full max-w-2xl mx-auto">
      <div
        {...getRootProps()}
        className={cn(
          "relative group cursor-pointer overflow-hidden rounded-3xl border-2 border-dashed transition-all duration-300 min-h-[300px] flex flex-col items-center justify-center p-8",
          isDragActive ? "border-primary bg-primary/5 scale-[1.02]" : "border-border/50 hover:border-primary/50 hover:bg-secondary/30",
          (isUploading || activeFile) && "border-solid border-border bg-card/50",
          error && "border-destructive/50 bg-destructive/5"
        )}
      >
        <input {...getInputProps()} />

        <AnimatePresence mode="wait">
          {!activeFile ? (
            <motion.div
              key="prompt"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="text-center space-y-4"
            >
              <div className="w-20 h-20 rounded-full bg-secondary flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300 shadow-xl shadow-black/10">
                <UploadCloud className="w-10 h-10 text-muted-foreground group-hover:text-primary transition-colors" />
              </div>
              <div>
                <h3 className="text-xl font-bold font-display text-foreground mb-2">
                  Drop your video here
                </h3>
                <p className="text-muted-foreground text-sm max-w-xs mx-auto">
                  Support for MP4, MOV, AVI up to 2GB.
                  <br />
                  <span className="text-primary/80">Click to browse files</span>
                </p>
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="preview"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="w-full max-w-md"
            >
              <div className="flex items-center gap-4 bg-background/50 p-4 rounded-xl border border-border/50 mb-6 backdrop-blur-sm">
                <div className="w-12 h-12 rounded-lg bg-primary/20 flex items-center justify-center flex-shrink-0">
                  <FileVideo className="w-6 h-6 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-foreground truncate">{activeFile.name}</p>
                  <p className="text-xs text-muted-foreground">
                    {(activeFile.size / (1024 * 1024)).toFixed(2)} MB
                  </p>
                </div>
                {isUploading ? (
                  <div className="text-sm font-bold text-primary font-mono">{progress}%</div>
                ) : (
                  <button 
                    onClick={(e) => { e.stopPropagation(); /* clear logic if needed */ }}
                    className="text-xs text-primary hover:underline"
                  >
                    Change
                  </button>
                )}
              </div>

              {isUploading && (
                <div className="space-y-2">
                  <div className="h-2 w-full bg-secondary rounded-full overflow-hidden">
                    <motion.div 
                      className="h-full bg-gradient-to-r from-primary to-accent"
                      initial={{ width: 0 }}
                      animate={{ width: `${progress}%` }}
                      transition={{ duration: 0.2 }}
                    />
                  </div>
                  <p className="text-center text-xs text-muted-foreground animate-pulse">
                    Uploading to secure storage...
                  </p>
                </div>
              )}

              {error && (
                <div className="flex items-center gap-2 text-destructive bg-destructive/10 p-3 rounded-lg text-sm mt-4">
                  <AlertCircle className="w-4 h-4" />
                  <span className="font-medium">{error}</span>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
