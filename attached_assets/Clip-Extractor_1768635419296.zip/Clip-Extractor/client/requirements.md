## Packages
framer-motion | Page transitions, list animations, and micro-interactions
react-player | For playing original videos and extracted clips
date-fns | Formatting timestamps and dates
clsx | Utility for constructing className strings conditionally
tailwind-merge | Utility for merging Tailwind CSS classes safely

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
