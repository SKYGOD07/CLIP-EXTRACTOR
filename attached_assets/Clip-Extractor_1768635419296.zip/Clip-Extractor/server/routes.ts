import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { registerObjectStorageRoutes, ObjectStorageService } from "./replit_integrations/object_storage";
import { processVideo } from "./lib/video-processor";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // Register Object Storage Routes (for uploads/downloads)
  registerObjectStorageRoutes(app);

  const objectStorage = new ObjectStorageService();

  // Video Routes
  app.get(api.videos.list.path, async (req, res) => {
    const videos = await storage.getVideos();
    res.json(videos);
  });

  app.get(api.videos.get.path, async (req, res) => {
    const video = await storage.getVideo(Number(req.params.id));
    if (!video) {
      return res.status(404).json({ message: "Video not found" });
    }
    res.json(video);
  });

  app.post(api.videos.create.path, async (req, res) => {
    try {
      const input = api.videos.create.input.parse(req.body);
      const video = await storage.createVideo(input);
      res.status(201).json(video);
      
      // Auto-trigger processing? Or let user trigger it?
      // Let's auto-trigger for better UX, but keep the separate process endpoint too.
      // processVideo(video.id).catch(console.error); 
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  app.post(api.videos.process.path, async (req, res) => {
    const id = Number(req.params.id);
    const video = await storage.getVideo(id);
    if (!video) {
      return res.status(404).json({ message: "Video not found" });
    }

    // Trigger async processing
    processVideo(id).catch(console.error);

    res.json({ message: "Processing started" });
  });

  // Helper to get upload URL (used by custom upload flow if needed, 
  // though ObjectUploader component usually handles this via its own internal logic or this endpoint)
  // `registerObjectStorageRoutes` already adds `/api/uploads/request-url`.
  // But we defined `api.videos.uploadUrl` in shared/routes.ts which points to `/api/upload-url`.
  // Let's implement that to match our API contract.
  app.post(api.videos.uploadUrl.path, async (req, res) => {
    try {
        const { filename, contentType, size } = req.body;
        const uploadUrl = await objectStorage.getObjectEntityUploadURL();
        const objectPath = objectStorage.normalizeObjectEntityPath(uploadUrl);
        
        // Return both the GCS upload URL and the local serving URL
        res.json({
            uploadUrl,
            publicUrl: objectPath
        });
    } catch (error) {
        console.error("Upload URL error:", error);
        res.status(500).json({ message: "Failed to generate upload URL" });
    }
  });

  return httpServer;
}
