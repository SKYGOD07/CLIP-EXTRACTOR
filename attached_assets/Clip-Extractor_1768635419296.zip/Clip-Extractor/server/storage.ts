import { db } from "./db";
import { videos, clips, type Video, type InsertVideo, type Clip, type InsertClip } from "@shared/schema";
import { eq } from "drizzle-orm";

export interface IStorage {
  // Videos
  getVideo(id: number): Promise<(Video & { clips: Clip[] }) | undefined>;
  getVideos(): Promise<Video[]>;
  createVideo(video: InsertVideo): Promise<Video>;
  updateVideoStatus(id: number, status: string, progress?: number, error?: string): Promise<Video>;
  
  // Clips
  createClip(clip: InsertClip): Promise<Clip>;
  getClipsForVideo(videoId: number): Promise<Clip[]>;
}

export class DatabaseStorage implements IStorage {
  async getVideo(id: number): Promise<(Video & { clips: Clip[] }) | undefined> {
    const video = await db.query.videos.findFirst({
      where: eq(videos.id, id),
    });
    
    if (!video) return undefined;
    
    const videoClips = await db.select().from(clips).where(eq(clips.videoId, id));
    
    return { ...video, clips: videoClips };
  }

  async getVideos(): Promise<Video[]> {
    return await db.select().from(videos).orderBy(videos.createdAt);
  }

  async createVideo(insertVideo: InsertVideo): Promise<Video> {
    const [video] = await db.insert(videos).values(insertVideo).returning();
    return video;
  }

  async updateVideoStatus(id: number, status: string, progress?: number, error?: string): Promise<Video> {
    const [video] = await db
      .update(videos)
      .set({ 
        status, 
        progress: progress !== undefined ? progress : undefined,
        error: error !== undefined ? error : undefined
      })
      .where(eq(videos.id, id))
      .returning();
    return video;
  }

  async createClip(insertClip: InsertClip): Promise<Clip> {
    const [clip] = await db.insert(clips).values(insertClip).returning();
    return clip;
  }

  async getClipsForVideo(videoId: number): Promise<Clip[]> {
    return await db.select().from(clips).where(eq(clips.videoId, videoId));
  }
}

export const storage = new DatabaseStorage();
