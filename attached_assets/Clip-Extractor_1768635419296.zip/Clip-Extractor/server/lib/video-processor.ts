import fs from "fs";
import path from "path";
import { randomUUID } from "crypto";
import ffmpeg from "fluent-ffmpeg";
import { GoogleGenAI } from "@google/genai";
import { storage } from "../storage";
import { ObjectStorageService } from "../replit_integrations/object_storage";

// Initialize Gemini
const ai = new GoogleGenAI({
  apiKey: process.env.AI_INTEGRATIONS_GEMINI_API_KEY,
  httpOptions: {
    apiVersion: "",
    baseUrl: process.env.AI_INTEGRATIONS_GEMINI_BASE_URL,
  },
});

const objectStorage = new ObjectStorageService();

async function downloadFile(url: string, destPath: string) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Failed to download: ${res.statusText}`);
  const buffer = await res.arrayBuffer();
  fs.writeFileSync(destPath, Buffer.from(buffer));
}

async function extractFrames(videoPath: string, outputDir: string, intervalSeconds: number = 10) {
  return new Promise<string[]>((resolve, reject) => {
    const files: string[] = [];
    ffmpeg(videoPath)
      .on("filenames", (filenames) => {
        filenames.forEach((f) => files.push(path.join(outputDir, f)));
      })
      .on("end", () => resolve(files))
      .on("error", (err) => reject(err))
      .screenshots({
        count: undefined, // Use timemarks
        timemarks: ["0", "10", "20", "30", "40", "50", "60", "70", "80", "90", "100", "110", "120"], // TODO: Dynamic based on duration
        filename: "thumb-%s.png",
        folder: outputDir,
        size: "512x?",
      });
  });
}

// Better version of extractFrames that extracts every N seconds dynamically
async function extractFramesDynamic(videoPath: string, outputDir: string, interval: number = 10): Promise<string[]> {
  // First get duration
  const duration = await new Promise<number>((resolve, reject) => {
    ffmpeg.ffprobe(videoPath, (err, metadata) => {
      if (err) reject(err);
      else resolve(metadata.format.duration || 0);
    });
  });

  const timemarks: string[] = [];
  for (let i = 0; i < duration; i += interval) {
    timemarks.push(i.toString());
  }

  return new Promise<string[]>((resolve, reject) => {
    const files: string[] = [];
    ffmpeg(videoPath)
      .on("filenames", (filenames) => {
        filenames.forEach((f) => files.push(path.join(outputDir, f)));
      })
      .on("end", () => resolve(files))
      .on("error", (err) => reject(err))
      .screenshots({
        timemarks: timemarks,
        filename: "frame-%s.png",
        folder: outputDir,
        size: "512x?",
      });
  });
}

async function cutClip(videoPath: string, startTime: string, endTime: string, outputPath: string) {
  return new Promise<void>((resolve, reject) => {
    ffmpeg(videoPath)
      .setStartTime(startTime)
      .setDuration(parseFloat(endTime) - parseFloat(startTime))
      .output(outputPath)
      .on("end", () => resolve())
      .on("error", (err) => reject(err))
      .run();
  });
}

export async function processVideo(videoId: number) {
  console.log(`Starting processing for video ${videoId}`);
  try {
    const video = await storage.getVideo(videoId);
    if (!video) throw new Error("Video not found");

    await storage.updateVideoStatus(videoId, "processing", 10);

    // 1. Download Video
    const tempDir = path.join(process.cwd(), "temp", randomUUID());
    if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });
    
    const videoPath = path.join(tempDir, "input.mp4");
    
    // Check if url is absolute or relative (object storage)
    let downloadUrl = video.originalUrl;
    // If it's a relative path from our own object storage, we need to construct a fetchable URL or use the client
    // For simplicity, we'll assume the client uploaded to a public URL or we use the internal object storage logic
    // Actually, `video.originalUrl` from our frontend flow is likely the public URL or presigned URL. 
    // If it's from `api.uploadUrl`, it's a Google Cloud Storage URL.
    
    await downloadFile(downloadUrl, videoPath);
    await storage.updateVideoStatus(videoId, "processing", 30);

    // 2. Extract Frames
    const framesDir = path.join(tempDir, "frames");
    if (!fs.existsSync(framesDir)) fs.mkdirSync(framesDir);
    const framePaths = await extractFramesDynamic(videoPath, framesDir, 15); // Every 15s to save tokens
    await storage.updateVideoStatus(videoId, "processing", 50);

    // 3. Analyze with Gemini
    const frameParts = framePaths.map((p) => {
        const data = fs.readFileSync(p).toString("base64");
        return {
            inlineData: {
                mimeType: "image/png",
                data: data
            }
        };
    });

    const prompt = `
      You are an expert video editor. Analyze these frames extracted from a video (1 frame every 15 seconds).
      Identify 3-5 distinct, high-value clips that would be viral or interesting.
      For each clip, provide:
      - start_time: approximate start time in seconds (calculated as frame_index * 15)
      - end_time: approximate end time in seconds
      - summary: a catchy title/summary
      - virality_score: 1-100

      Return ONLY a JSON array of objects with these keys. No markdown.
      Example: [{"start_time": 10, "end_time": 30, "summary": "Funny cat jump", "virality_score": 90}]
    `;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: [{
        role: "user",
        parts: [...frameParts, { text: prompt }]
      }]
    });

    const responseText = response.candidates?.[0]?.content?.parts?.[0]?.text || "[]";
    const cleanJson = responseText.replace(/```json/g, "").replace(/```/g, "").trim();
    
    let clipsData;
    try {
        clipsData = JSON.parse(cleanJson);
    } catch (e) {
        console.error("Failed to parse Gemini response:", cleanJson);
        throw new Error("Failed to parse AI response");
    }

    await storage.updateVideoStatus(videoId, "processing", 70);

    // 4. Cut Clips
    const clipsDir = path.join(tempDir, "clips");
    if (!fs.existsSync(clipsDir)) fs.mkdirSync(clipsDir);

    for (const clip of clipsData) {
      const clipFilename = `clip-${randomUUID()}.mp4`;
      const clipPath = path.join(clipsDir, clipFilename);
      
      await cutClip(videoPath, clip.start_time.toString(), clip.end_time.toString(), clipPath);

      // 5. Upload Clip
      // We need to upload this back to object storage.
      // We can use the ObjectStorageService's internal methods if we expose them or just use the presigned URL flow manually?
      // Actually, since we are on the server, we can use the `objectStorageClient` directly if exported, or `ObjectStorageService`.
      // `ObjectStorageService` helper methods are mostly for public/private path resolution.
      // Let's use the private object dir and upload.
      
      const uploadUrl = await objectStorage.getObjectEntityUploadURL(); // Returns a PUT URL
      const objectPath = objectStorage.normalizeObjectEntityPath(uploadUrl);
      
      // Upload using fetch
      const fileContent = fs.readFileSync(clipPath);
      await fetch(uploadUrl, {
          method: "PUT",
          body: fileContent,
          headers: { "Content-Type": "video/mp4" }
      });

      // 6. Save Clip to DB
      // We need a public URL or a way to serve it. 
      // The `objectPath` is like `/objects/uploads/...` which our `routes.ts` serves via `GET /objects/:objectPath`.
      // So we save `objectPath` as the URL.
      
      await storage.createClip({
        videoId,
        url: objectPath, // Frontend uses this to fetch from our server
        startTime: clip.start_time.toString(),
        endTime: clip.end_time.toString(),
        summary: clip.summary,
        viralityScore: clip.virality_score
      });
    }

    await storage.updateVideoStatus(videoId, "completed", 100);

    // Cleanup
    fs.rmSync(tempDir, { recursive: true, force: true });

  } catch (error) {
    console.error("Video processing error:", error);
    await storage.updateVideoStatus(videoId, "failed", 0, (error as Error).message);
  }
}
